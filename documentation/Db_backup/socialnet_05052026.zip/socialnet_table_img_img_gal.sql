
-- --------------------------------------------------------

--
-- Table structure for table `img_img_gal`
--
-- Creation: Feb 24, 2026 at 12:47 PM
--

DROP TABLE IF EXISTS `img_img_gal`;
CREATE TABLE IF NOT EXISTS `img_img_gal` (
  `uniqueId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `imageId` int(10) UNSIGNED NOT NULL,
  `galleryId` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`uniqueId`),
  KEY `imageIdiig_fk` (`imageId`),
  KEY `galleryId_fk` (`galleryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `img_img_gal`:
--   `galleryId`
--       `image_gallery` -> `galleryId`
--   `imageId`
--       `image` -> `imageId`
--

--
-- Triggers `img_img_gal`
--
DROP TRIGGER IF EXISTS `imageInGalleryLogAfterDelete`;
DELIMITER $$
CREATE TRIGGER `imageInGalleryLogAfterDelete` AFTER DELETE ON `img_img_gal` FOR EACH ROW begin 
call saveLog('delete','iig');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `imageInGalleryLogAfterInsert`;
DELIMITER $$
CREATE TRIGGER `imageInGalleryLogAfterInsert` AFTER INSERT ON `img_img_gal` FOR EACH ROW begin 
call saveLog('insert','iig');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `imageInGalleryLogAfterUpdate`;
DELIMITER $$
CREATE TRIGGER `imageInGalleryLogAfterUpdate` AFTER UPDATE ON `img_img_gal` FOR EACH ROW begin 
call saveLog('update','iig');
end
$$
DELIMITER ;
