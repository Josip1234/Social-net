
-- --------------------------------------------------------

--
-- Table structure for table `profile`
--
-- Creation: Feb 24, 2026 at 12:47 PM
--

DROP TABLE IF EXISTS `profile`;
CREATE TABLE IF NOT EXISTS `profile` (
  `userId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `sex` char(1) NOT NULL,
  `dateOfBirth` date NOT NULL,
  `addressId` int(10) UNSIGNED DEFAULT NULL,
  `hashPassword` text NOT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `email` (`email`),
  KEY `addressId_fk` (`addressId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `profile`:
--   `addressId`
--       `address` -> `addressId`
--

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`userId`, `firstName`, `lastName`, `email`, `sex`, `dateOfBirth`, `addressId`, `hashPassword`) VALUES
(2, 'Josip', 'Admin', 'mainadmin@main.com', 'm', '1992-11-05', 1, '$2y$10$aY5UXzxviIvBa1YPuRMFP.0oqtLlltqQmjOUlTgkROrg1kFEFP.Su'),
(20, 'Novi', 'Korisnik', 'nkor@mail.com', 'm', '1995-04-29', 1, '$2y$10$KeOibLKzqmZUnW7xPlr0Ous8VPddR6sr2ul7/4J3Yalb/CeakDamC');

--
-- Triggers `profile`
--
DROP TRIGGER IF EXISTS `userDeleteProfileLog`;
DELIMITER $$
CREATE TRIGGER `userDeleteProfileLog` AFTER DELETE ON `profile` FOR EACH ROW begin 
call saveProfileLog('delete','profile',concat(old.firstName,' ',old.lastName),null);
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `userProfileLog`;
DELIMITER $$
CREATE TRIGGER `userProfileLog` AFTER INSERT ON `profile` FOR EACH ROW begin 
declare accTypeId int unsigned;
select acTypeId into accTypeId from accounttype where acTypeName='Regular';
if accTypeId is not null then
call saveProfileLog('insert','profile',concat(new.firstName,' ',new.lastName),null);
call autoInsertIntoProfileDet(new.userId,accTypeId, now(), 'Active');
else 
SIGNAL sqlstate '45000'
set message_text = 'There are no account type under this name. Please check data in the table account type.';
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `userUpdateProfileLog`;
DELIMITER $$
CREATE TRIGGER `userUpdateProfileLog` AFTER UPDATE ON `profile` FOR EACH ROW begin 
call saveProfileLog('update','profile',concat(new.firstName,' ',new.lastName),concat(old.firstName,' ',old.lastName));
end
$$
DELIMITER ;
