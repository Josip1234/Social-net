
-- --------------------------------------------------------

--
-- Table structure for table `image_gallery`
--
-- Creation: Feb 24, 2026 at 12:47 PM
--

DROP TABLE IF EXISTS `image_gallery`;
CREATE TABLE IF NOT EXISTS `image_gallery` (
  `galleryId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `galleryName` varchar(50) NOT NULL,
  `galleryDateAdded` datetime NOT NULL,
  `galleryDateUpdated` datetime DEFAULT NULL,
  PRIMARY KEY (`galleryId`),
  UNIQUE KEY `galleryName` (`galleryName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `image_gallery`:
--

--
-- Triggers `image_gallery`
--
DROP TRIGGER IF EXISTS `ImageGalleryLogAfterDelete`;
DELIMITER $$
CREATE TRIGGER `ImageGalleryLogAfterDelete` AFTER DELETE ON `image_gallery` FOR EACH ROW begin 
call saveLog('delete','imgal');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `ImageGalleryLogAfterInsert`;
DELIMITER $$
CREATE TRIGGER `ImageGalleryLogAfterInsert` AFTER INSERT ON `image_gallery` FOR EACH ROW begin 
call saveLog('insert','imgal');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `ImageGalleryLogAfterUpdate`;
DELIMITER $$
CREATE TRIGGER `ImageGalleryLogAfterUpdate` AFTER UPDATE ON `image_gallery` FOR EACH ROW begin 
call saveLog('update','imgal');
end
$$
DELIMITER ;
