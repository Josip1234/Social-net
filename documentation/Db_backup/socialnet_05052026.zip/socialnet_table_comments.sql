
-- --------------------------------------------------------

--
-- Table structure for table `comments`
--
-- Creation: Feb 24, 2026 at 12:47 PM
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `commentId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `commentContent` text NOT NULL,
  `markOfOffensiveness` enum('Offensive','Not offensive') DEFAULT NULL,
  `comDateUpdated` datetime NOT NULL,
  `comDateAdded` datetime NOT NULL,
  `commentLike` int(10) UNSIGNED NOT NULL,
  `commentDislike` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`commentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `comments`:
--

--
-- Triggers `comments`
--
DROP TRIGGER IF EXISTS `CommentLogAfterDelete`;
DELIMITER $$
CREATE TRIGGER `CommentLogAfterDelete` AFTER DELETE ON `comments` FOR EACH ROW begin 
call saveLog('delete','cmt');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `CommentLogAfterInsert`;
DELIMITER $$
CREATE TRIGGER `CommentLogAfterInsert` AFTER INSERT ON `comments` FOR EACH ROW begin 
call saveLog('insert','cmt');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `CommentLogAfterUpdate`;
DELIMITER $$
CREATE TRIGGER `CommentLogAfterUpdate` AFTER UPDATE ON `comments` FOR EACH ROW begin 
call saveLog('update','cmt');
end
$$
DELIMITER ;
