
-- --------------------------------------------------------

--
-- Table structure for table `address`
--
-- Creation: Feb 24, 2026 at 12:47 PM
--

DROP TABLE IF EXISTS `address`;
CREATE TABLE IF NOT EXISTS `address` (
  `addressId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `street` varchar(255) NOT NULL,
  `postNumber` varchar(20) NOT NULL,
  PRIMARY KEY (`addressId`),
  KEY `postNumber_fk` (`postNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `address`:
--   `postNumber`
--       `city` -> `postNumber`
--

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`addressId`, `street`, `postNumber`) VALUES
(1, 'Ivana Zeline 53', '10000');

--
-- Triggers `address`
--
DROP TRIGGER IF EXISTS `deleteAdrIntoDatabaseLogger`;
DELIMITER $$
CREATE TRIGGER `deleteAdrIntoDatabaseLogger` AFTER DELETE ON `address` FOR EACH ROW begin 
call saveLog('delete','adr');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `insertAdrIntoDatabaseLogger`;
DELIMITER $$
CREATE TRIGGER `insertAdrIntoDatabaseLogger` AFTER INSERT ON `address` FOR EACH ROW begin 
call saveLog('insert','adr');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `updateAdrIntoDatabaseLogger`;
DELIMITER $$
CREATE TRIGGER `updateAdrIntoDatabaseLogger` AFTER UPDATE ON `address` FOR EACH ROW begin 
call saveLog('update','adr');
end
$$
DELIMITER ;
