
-- --------------------------------------------------------

--
-- Table structure for table `profile_logger`
--
-- Creation: Feb 24, 2026 at 12:47 PM
-- Last update: May 05, 2026 at 12:40 PM
--

DROP TABLE IF EXISTS `profile_logger`;
CREATE TABLE IF NOT EXISTS `profile_logger` (
  `plId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userId` int(10) UNSIGNED NOT NULL,
  `message` text NOT NULL,
  `additionDate` datetime NOT NULL,
  `updateDate` datetime DEFAULT NULL,
  `deleteDate` datetime DEFAULT NULL,
  PRIMARY KEY (`plId`),
  KEY `userIdpl_fk` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `profile_logger`:
--   `userId`
--       `profile` -> `userId`
--

--
-- Dumping data for table `profile_logger`
--

INSERT INTO `profile_logger` (`plId`, `userId`, `message`, `additionDate`, `updateDate`, `deleteDate`) VALUES
(1, 2, 'User with email mainadmin@main.com has been logged in', '2026-02-28 14:20:29', NULL, NULL),
(2, 2, 'Unsuccessfull login by mainadmin@main.com', '2026-02-28 14:33:57', NULL, NULL),
(3, 2, 'User with email mainadmin@main.com has been logged in', '2026-02-28 14:43:17', NULL, NULL),
(4, 2, 'User with email mainadmin@main.com has been logged in', '2026-02-28 14:45:49', NULL, NULL),
(5, 2, 'User with email mainadmin@main.com has been logged in', '2026-02-28 14:47:42', NULL, NULL),
(6, 2, 'User with email mainadmin@main.com has been logged in', '2026-02-28 14:48:03', NULL, NULL),
(7, 2, 'User with email mainadmin@main.com has been logged in', '2026-02-28 14:51:24', NULL, NULL),
(8, 2, 'User with email mainadmin@main.com has been logged in', '2026-02-28 14:56:10', NULL, NULL),
(9, 2, 'User with email mainadmin@main.com has been logged in', '2026-02-28 14:56:38', NULL, NULL),
(10, 2, 'User with email mainadmin@main.com has been logged in', '2026-02-28 14:58:01', NULL, NULL),
(11, 2, 'User with email mainadmin@main.com has been logged in', '2026-03-02 10:12:26', NULL, NULL),
(12, 2, 'User with email mainadmin@main.com has been logged in', '2026-03-02 10:25:40', NULL, NULL),
(13, 2, 'User with email mainadmin@main.com has been logged in', '2026-03-03 18:59:43', '2026-03-03 19:20:44', NULL),
(14, 2, 'User with email mainadmin@main.com has been logged in', '2026-03-03 19:28:33', '2026-03-03 19:28:37', NULL),
(15, 2, 'User with email mainadmin@main.com has been logged in', '2026-03-03 19:37:56', '2026-03-03 19:38:00', NULL),
(16, 2, 'User with email mainadmin@main.com has been logged in', '2026-03-05 14:17:09', '2026-03-05 14:17:39', NULL),
(17, 2, 'User with email mainadmin@main.com has been logged out.', '2026-03-05 14:17:39', NULL, NULL),
(18, 2, 'User with email mainadmin@main.com has been logged in', '2026-03-07 16:38:31', '2026-03-07 16:39:53', NULL),
(19, 2, 'User with email mainadmin@main.com has been logged out.', '2026-03-07 16:39:53', NULL, NULL),
(20, 2, 'User with email mainadmin@main.com has been logged in', '2026-03-09 10:18:07', '2026-03-09 10:23:26', NULL),
(21, 2, 'User with email mainadmin@main.com has been logged out.', '2026-03-09 10:23:26', NULL, NULL),
(22, 2, 'User with email mainadmin@main.com has been logged in', '2026-03-09 10:24:03', '2026-03-09 10:24:07', NULL),
(23, 2, 'User with email mainadmin@main.com has been logged out.', '2026-03-09 10:24:07', NULL, NULL),
(24, 2, 'Unsuccessfull login by mainadmin@main.com', '2026-04-04 14:51:55', NULL, NULL),
(25, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-04 14:52:30', NULL, NULL),
(26, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-06 15:35:28', '2026-04-06 16:50:17', NULL),
(27, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-06 16:50:17', NULL, NULL),
(28, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-09 13:26:59', '2026-04-09 13:48:36', NULL),
(29, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-09 13:48:36', NULL, NULL),
(30, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-09 18:05:47', NULL, NULL),
(31, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-10 10:38:44', '2026-04-10 11:03:52', NULL),
(32, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-10 11:03:52', NULL, NULL),
(33, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-10 15:09:56', '2026-04-10 16:15:22', NULL),
(34, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-10 16:15:22', NULL, NULL),
(35, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-11 14:34:55', '2026-04-11 15:09:55', NULL),
(36, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-11 15:09:55', NULL, NULL),
(37, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-11 17:47:47', '2026-04-11 19:05:06', NULL),
(38, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-11 19:05:06', NULL, NULL),
(42, 2, 'Unsuccessfull login by mainadmin@main.com', '2026-04-11 19:07:20', NULL, NULL),
(43, 2, 'Unsuccessfull login by mainadmin@main.com', '2026-04-11 19:07:34', NULL, NULL),
(44, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-11 19:07:48', '2026-04-11 19:08:36', NULL),
(45, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-11 19:08:36', NULL, NULL),
(49, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-11 19:23:09', '2026-04-11 19:23:12', NULL),
(50, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-11 19:23:12', NULL, NULL),
(55, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-12 11:28:42', '2026-04-12 11:51:51', NULL),
(56, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-12 11:51:51', NULL, NULL),
(57, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-13 13:16:54', '2026-04-13 13:58:08', NULL),
(58, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-13 13:58:08', NULL, NULL),
(59, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-14 18:04:03', '2026-04-14 18:36:00', NULL),
(60, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-14 18:36:00', NULL, NULL),
(61, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-15 14:22:43', '2026-04-15 14:52:01', NULL),
(62, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-15 14:52:01', NULL, NULL),
(63, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-15 14:54:30', NULL, NULL),
(64, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-18 15:45:38', '2026-04-18 17:12:44', NULL),
(65, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-18 17:12:45', NULL, NULL),
(66, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-19 10:28:41', NULL, NULL),
(67, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-20 16:39:11', '2026-04-20 17:39:26', NULL),
(68, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-20 17:39:26', NULL, NULL),
(69, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-29 09:05:44', '2026-04-29 09:06:45', NULL),
(70, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-29 09:06:45', NULL, NULL),
(78, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-29 09:30:47', '2026-04-29 09:32:01', NULL),
(79, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-29 09:32:02', NULL, NULL),
(86, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-29 09:54:24', '2026-04-29 09:55:15', NULL),
(87, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-29 09:55:15', NULL, NULL),
(91, 20, 'User with email nkor@mail.com has been logged in', '2026-04-29 10:07:12', '2026-04-29 10:11:21', NULL),
(92, 20, 'User with email nkor@mail.com has been logged out.', '2026-04-29 10:11:21', NULL, NULL),
(93, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-29 10:11:31', '2026-04-29 10:12:03', NULL),
(94, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-29 10:12:03', NULL, NULL),
(95, 20, 'User with email nkor@mail.com has been logged in', '2026-04-29 10:12:21', '2026-04-29 10:16:54', NULL),
(96, 20, 'User with email nkor@mail.com has been logged out.', '2026-04-29 10:16:54', NULL, NULL),
(97, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-29 10:17:14', '2026-04-29 10:17:26', NULL),
(98, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-29 10:17:26', NULL, NULL),
(99, 20, 'User with email nkor@mail.com has been logged in', '2026-04-29 10:18:28', '2026-04-29 10:37:31', NULL),
(100, 20, 'User with email nkor@mail.com has been logged out.', '2026-04-29 10:37:31', NULL, NULL),
(101, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-29 10:37:41', '2026-04-29 10:37:48', NULL),
(102, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-29 10:37:48', NULL, NULL),
(103, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-30 15:00:12', '2026-04-30 15:04:58', NULL),
(104, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-30 15:04:58', NULL, NULL),
(105, 20, 'User with email nkor@mail.com has been logged in', '2026-04-30 15:05:03', '2026-04-30 15:05:18', NULL),
(106, 20, 'User with email nkor@mail.com has been logged out.', '2026-04-30 15:05:18', NULL, NULL),
(107, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-30 15:05:30', '2026-04-30 15:25:26', NULL),
(108, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-30 15:25:26', NULL, NULL),
(109, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-30 15:25:42', '2026-04-30 15:27:32', NULL),
(110, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-30 15:27:32', NULL, NULL),
(111, 2, 'User with email mainadmin@main.com has been logged in', '2026-04-30 15:28:08', '2026-04-30 15:34:19', NULL),
(112, 2, 'User with email mainadmin@main.com has been logged out.', '2026-04-30 15:34:19', NULL, NULL),
(113, 2, 'User with email mainadmin@main.com has been logged in', '2026-05-03 16:02:53', '2026-05-03 16:28:05', NULL),
(114, 2, 'User with email mainadmin@main.com has been logged out.', '2026-05-03 16:28:05', NULL, NULL),
(115, 2, 'User with email mainadmin@main.com has been logged in', '2026-05-04 13:07:08', '2026-05-04 14:18:42', NULL),
(116, 2, 'User with email mainadmin@main.com has been logged out.', '2026-05-04 14:18:42', NULL, NULL),
(117, 2, 'User with email mainadmin@main.com has been logged in', '2026-05-04 14:19:00', '2026-05-04 14:55:11', NULL),
(118, 2, 'User with email mainadmin@main.com has been logged out.', '2026-05-04 14:55:11', NULL, NULL),
(119, 2, 'User with email mainadmin@main.com has been logged in', '2026-05-05 13:37:27', '2026-05-05 13:40:49', NULL),
(120, 2, 'User with email mainadmin@main.com has been logged out.', '2026-05-05 13:40:49', NULL, NULL),
(121, 2, 'User with email mainadmin@main.com has been logged in', '2026-05-05 13:41:06', NULL, NULL),
(122, 2, 'User with email mainadmin@main.com has been logged in', '2026-05-05 13:42:55', '2026-05-05 14:38:54', NULL),
(123, 2, 'User with email mainadmin@main.com has been logged out.', '2026-05-05 14:38:54', NULL, NULL),
(124, 20, 'User with email nkor@mail.com has been logged in', '2026-05-05 14:39:13', '2026-05-05 14:40:22', NULL),
(125, 20, 'User with email nkor@mail.com has been logged out.', '2026-05-05 14:40:22', NULL, NULL);

--
-- Triggers `profile_logger`
--
DROP TRIGGER IF EXISTS `logContentAfterDelete`;
DELIMITER $$
CREATE TRIGGER `logContentAfterDelete` AFTER DELETE ON `profile_logger` FOR EACH ROW begin 
call saveLog2('delete','pl');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logContentAfterUpdate`;
DELIMITER $$
CREATE TRIGGER `logContentAfterUpdate` AFTER INSERT ON `profile_logger` FOR EACH ROW begin 
call saveLog2('update','pl');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logContentAfterinsert`;
DELIMITER $$
CREATE TRIGGER `logContentAfterinsert` AFTER INSERT ON `profile_logger` FOR EACH ROW begin 
call saveLog2('insert','pl');
end
$$
DELIMITER ;
