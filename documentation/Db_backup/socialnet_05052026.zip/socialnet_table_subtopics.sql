
-- --------------------------------------------------------

--
-- Table structure for table `subtopics`
--
-- Creation: Feb 24, 2026 at 12:47 PM
--

DROP TABLE IF EXISTS `subtopics`;
CREATE TABLE IF NOT EXISTS `subtopics` (
  `subTopicsId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `topicId` int(10) UNSIGNED NOT NULL,
  `subTopicContent` text NOT NULL,
  `subTopicDateAdded` datetime NOT NULL,
  `subTopicDateUpdated` datetime NOT NULL,
  `subtopicLike` int(10) UNSIGNED NOT NULL,
  `subtopicDislike` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`subTopicsId`),
  UNIQUE KEY `subTopicContent` (`subTopicContent`) USING HASH,
  KEY `topicId_fk` (`topicId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `subtopics`:
--   `topicId`
--       `topics` -> `topicId`
--

--
-- Triggers `subtopics`
--
DROP TRIGGER IF EXISTS `logContentAfterDeleteSt`;
DELIMITER $$
CREATE TRIGGER `logContentAfterDeleteSt` AFTER DELETE ON `subtopics` FOR EACH ROW begin 
call saveLog2('delete','st');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logContentAfterInsertSt`;
DELIMITER $$
CREATE TRIGGER `logContentAfterInsertSt` AFTER INSERT ON `subtopics` FOR EACH ROW begin 
call saveLog2('insert','st');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logContentAfterUpdateSt`;
DELIMITER $$
CREATE TRIGGER `logContentAfterUpdateSt` AFTER UPDATE ON `subtopics` FOR EACH ROW begin 
call saveLog2('update','st');
end
$$
DELIMITER ;
