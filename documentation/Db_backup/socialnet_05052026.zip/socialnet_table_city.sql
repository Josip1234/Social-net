
-- --------------------------------------------------------

--
-- Table structure for table `city`
--
-- Creation: Feb 24, 2026 at 12:47 PM
--

DROP TABLE IF EXISTS `city`;
CREATE TABLE IF NOT EXISTS `city` (
  `postNumber` varchar(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `stateId` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`postNumber`),
  KEY `stateId_fk` (`stateId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `city`:
--   `stateId`
--       `state` -> `stateId`
--

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`postNumber`, `name`, `stateId`) VALUES
('10000', 'Zagreb', 1),
('10450', 'Jastrebarsko', 1),
('31309', 'Kneževi Vinogradi', 1),
('34000', 'Požega', 1),
('34310', 'Pleternica', 1),
('34311', 'Kuzmica', 1),
('34550', 'Pakrac', 1),
('35000', 'Slavonski Brod', 1),
('44213', 'Kratečko', 1),
('44330', 'Novska', 1),
('47240', 'Slunj', 1),
('52434', 'Boljun', 1);

--
-- Triggers `city`
--
DROP TRIGGER IF EXISTS `UserLogAfterDeleteOnCity`;
DELIMITER $$
CREATE TRIGGER `UserLogAfterDeleteOnCity` AFTER DELETE ON `city` FOR EACH ROW begin 
call saveLog('delete','city');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `UserLogAfterInsertOnCity`;
DELIMITER $$
CREATE TRIGGER `UserLogAfterInsertOnCity` AFTER INSERT ON `city` FOR EACH ROW begin 
call saveLog('insert','city');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `UserLogAfterUpdateOnCity`;
DELIMITER $$
CREATE TRIGGER `UserLogAfterUpdateOnCity` AFTER UPDATE ON `city` FOR EACH ROW begin 
call saveLog('update','city');
end
$$
DELIMITER ;
