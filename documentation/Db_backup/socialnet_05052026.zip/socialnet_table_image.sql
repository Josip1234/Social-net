
-- --------------------------------------------------------

--
-- Table structure for table `image`
--
-- Creation: Feb 24, 2026 at 12:47 PM
--

DROP TABLE IF EXISTS `image`;
CREATE TABLE IF NOT EXISTS `image` (
  `imageId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userId` int(10) UNSIGNED NOT NULL,
  `imageName` varchar(50) NOT NULL,
  `url` text NOT NULL,
  `profileMarkImage` char(1) NOT NULL,
  PRIMARY KEY (`imageId`),
  UNIQUE KEY `url` (`url`) USING HASH,
  KEY `userid_imgid_fk` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `image`:
--   `userId`
--       `profile` -> `userId`
--

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`imageId`, `userId`, `imageName`, `url`, `profileMarkImage`) VALUES
(1, 2, 'slikica.net', 'social_net/2/slika.png', ''),
(2, 2, 'image_69df9378c2f84.jpeg', 'C:\\xampp\\htdocs\\Social-net\\Web_application\\app\\Helpers../../../public/assets/images/2/image_69df9378c2f84.jpeg', ''),
(3, 2, 'image_69df950f4ed11.jpeg', 'C:\\xampp\\htdocs\\Social-net\\Web_application\\app\\Helpers../../../public/assets/images/2/image_69df950f4ed11.jpeg', ''),
(4, 2, 'image_69df9758a6850.jpeg', 'C:\\xampp\\htdocs\\Social-net\\Web_application\\app\\Helpers../../../public/assets/images/2/image_69df9758a6850.jpeg', ''),
(5, 2, 'image_69df979edfecf.jpeg', 'C:\\xampp\\htdocs\\Social-net\\Web_application\\app\\Helpers../../../public/assets/images/2/image_69df979edfecf.jpeg', ''),
(6, 2, 'image_69e38dd64da8c.webp', 'C:\\xampp\\htdocs\\Social-net\\Web_application\\app\\Helpers../../../public/assets/images/2/image_69e38dd64da8c.webp', ''),
(7, 2, 'image_69e38f6f32948.jpg', 'C:\\xampp\\htdocs\\Social-net\\Web_application\\app\\Helpers../../../public/assets/images/2/image_69e38f6f32948.jpg', ''),
(8, 2, 'image_69e3922d3316b.webp', 'C:\\xampp\\htdocs\\Social-net\\Web_application\\app\\Helpers../../../public/assets/images/2/image_69e3922d3316b.webp', ''),
(9, 2, 'image_69e39497bb7b1.webp', 'wp14494675.webp', ''),
(10, 2, 'image_69e39df3f1be0.jpg', 'wp12965257-asus-vivobook-15-wallpapers.jpg', ''),
(12, 20, 'some', 'some', ''),
(13, 20, 'image_69f1c34501b98.jpg', 'index3.jpg', 'p'),
(14, 2, 'image_69f35a1c888df.webp', 'd00791ae-ubuntu_cli_cheat_sheet_2025.webp', 'p');

--
-- Triggers `image`
--
DROP TRIGGER IF EXISTS `ImageLogAfterDelete`;
DELIMITER $$
CREATE TRIGGER `ImageLogAfterDelete` AFTER DELETE ON `image` FOR EACH ROW begin 
call saveLog('delete','img');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `ImageLogAfterInsert`;
DELIMITER $$
CREATE TRIGGER `ImageLogAfterInsert` AFTER INSERT ON `image` FOR EACH ROW begin 
call saveLog('insert','img');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `ImageLogAfterUpdate`;
DELIMITER $$
CREATE TRIGGER `ImageLogAfterUpdate` AFTER UPDATE ON `image` FOR EACH ROW begin 
call saveLog('update','img');
end
$$
DELIMITER ;
