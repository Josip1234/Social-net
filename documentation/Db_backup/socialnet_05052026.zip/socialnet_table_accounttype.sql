
-- --------------------------------------------------------

--
-- Table structure for table `accounttype`
--
-- Creation: Feb 24, 2026 at 12:47 PM
--

DROP TABLE IF EXISTS `accounttype`;
CREATE TABLE IF NOT EXISTS `accounttype` (
  `acTypeId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `acTypeName` varchar(30) NOT NULL,
  `listOfPrivileges` text NOT NULL,
  PRIMARY KEY (`acTypeId`),
  UNIQUE KEY `acTypeName` (`acTypeName`),
  UNIQUE KEY `listOfPrivileges` (`listOfPrivileges`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `accounttype`:
--

--
-- Dumping data for table `accounttype`
--

INSERT INTO `accounttype` (`acTypeId`, `acTypeName`, `listOfPrivileges`) VALUES
(1, 'Admin', 'ALL PRIVILEGES'),
(2, 'Regular', 'Create,insert,delete,select');

--
-- Triggers `accounttype`
--
DROP TRIGGER IF EXISTS `deleteTypeLog`;
DELIMITER $$
CREATE TRIGGER `deleteTypeLog` AFTER DELETE ON `accounttype` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000'
set message_text='User is not admin. Operation not allowed.';
else
call saveLog('delete','at');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `insertTypeLog`;
DELIMITER $$
CREATE TRIGGER `insertTypeLog` AFTER INSERT ON `accounttype` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000'
set message_text='User is not admin. Operation not allowed.';
else
call saveLog('insert','at');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `limitAccountTypeTableBeforeDelete`;
DELIMITER $$
CREATE TRIGGER `limitAccountTypeTableBeforeDelete` BEFORE DELETE ON `accounttype` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000'
set message_text='User is not admin. Operation not allowed.';
else
call limitUseOfCudOperations('delete');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `limitAccountTypeTableBeforeInsert`;
DELIMITER $$
CREATE TRIGGER `limitAccountTypeTableBeforeInsert` BEFORE INSERT ON `accounttype` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000'
set message_text='User is not admin. Operation not allowed.';
else
call limitUseOfCudOperations('insert');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `limitAccountTypeTableBeforeUpdate`;
DELIMITER $$
CREATE TRIGGER `limitAccountTypeTableBeforeUpdate` BEFORE UPDATE ON `accounttype` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000'
set message_text='User is not admin. Operation not allowed.';
else
call limitUseOfCudOperations('update');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `updateTypeLog`;
DELIMITER $$
CREATE TRIGGER `updateTypeLog` AFTER UPDATE ON `accounttype` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000'
set message_text='User is not admin. Operation not allowed.';
else
call saveLog('update','at');
end if;
end
$$
DELIMITER ;
