
-- --------------------------------------------------------

--
-- Table structure for table `topics`
--
-- Creation: Feb 24, 2026 at 12:47 PM
--

DROP TABLE IF EXISTS `topics`;
CREATE TABLE IF NOT EXISTS `topics` (
  `topicId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userId` int(10) UNSIGNED NOT NULL,
  `topicContent` text NOT NULL,
  `topicDateAdded` datetime NOT NULL,
  `topicLike` int(10) UNSIGNED NOT NULL,
  `topicDislike` int(10) UNSIGNED NOT NULL,
  `topicDateUpdated` datetime NOT NULL,
  PRIMARY KEY (`topicId`),
  UNIQUE KEY `topicContent` (`topicContent`) USING HASH,
  KEY `user_id_topics_fk` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `topics`:
--   `userId`
--       `profile` -> `userId`
--

--
-- Triggers `topics`
--
DROP TRIGGER IF EXISTS `logContentAfterDeleteTop`;
DELIMITER $$
CREATE TRIGGER `logContentAfterDeleteTop` AFTER DELETE ON `topics` FOR EACH ROW begin 
call saveLog2('delete','top');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logContentAfterInsertTop`;
DELIMITER $$
CREATE TRIGGER `logContentAfterInsertTop` AFTER INSERT ON `topics` FOR EACH ROW begin 
call saveLog2('insert','top');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logContentAfterUpdateTop`;
DELIMITER $$
CREATE TRIGGER `logContentAfterUpdateTop` AFTER UPDATE ON `topics` FOR EACH ROW begin 
call saveLog2('update','top');
end
$$
DELIMITER ;
