
-- --------------------------------------------------------

--
-- Table structure for table `profiledetails`
--
-- Creation: Feb 24, 2026 at 12:47 PM
--

DROP TABLE IF EXISTS `profiledetails`;
CREATE TABLE IF NOT EXISTS `profiledetails` (
  `proDetId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userId` int(10) UNSIGNED NOT NULL,
  `acTypeId` int(10) UNSIGNED DEFAULT NULL,
  `registrationDate` datetime NOT NULL,
  `pdUpdateDate` datetime DEFAULT NULL,
  `accountStatus` enum('Active','Banned','Inactive') DEFAULT NULL,
  PRIMARY KEY (`proDetId`),
  KEY `userIdac_fk` (`userId`),
  KEY `acTypeId_fk` (`acTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `profiledetails`:
--   `acTypeId`
--       `accounttype` -> `acTypeId`
--   `userId`
--       `profile` -> `userId`
--

--
-- Dumping data for table `profiledetails`
--

INSERT INTO `profiledetails` (`proDetId`, `userId`, `acTypeId`, `registrationDate`, `pdUpdateDate`, `accountStatus`) VALUES
(2, 2, 1, '2026-02-28 13:46:21', '2026-02-28 13:55:18', 'Active'),
(11, 20, 2, '2026-04-29 10:07:08', NULL, 'Active');

--
-- Triggers `profiledetails`
--
DROP TRIGGER IF EXISTS `addedProfileDetailsLog`;
DELIMITER $$
CREATE TRIGGER `addedProfileDetailsLog` AFTER INSERT ON `profiledetails` FOR EACH ROW begin 
call saveLog('insert','pd');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `deletedProfileDetailsLog`;
DELIMITER $$
CREATE TRIGGER `deletedProfileDetailsLog` AFTER DELETE ON `profiledetails` FOR EACH ROW begin 
call saveLog('delete','pd');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `updatedProfileDetailsLog`;
DELIMITER $$
CREATE TRIGGER `updatedProfileDetailsLog` AFTER UPDATE ON `profiledetails` FOR EACH ROW begin 
call saveLog('update','pd');
end
$$
DELIMITER ;
