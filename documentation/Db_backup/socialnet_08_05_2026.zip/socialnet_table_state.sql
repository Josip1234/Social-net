
-- --------------------------------------------------------

--
-- Table structure for table `state`
--
-- Creation: Feb 24, 2026 at 12:47 PM
--

DROP TABLE IF EXISTS `state`;
CREATE TABLE IF NOT EXISTS `state` (
  `stateId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`stateId`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `state`:
--

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`stateId`, `name`) VALUES
(39, 'Afghanistan'),
(32, 'Algeria'),
(37, 'Angola'),
(26, 'Argentina'),
(17, 'Australia'),
(38, 'Austria'),
(16, 'Bangladesh'),
(30, 'Barbados'),
(12, 'Bosnia and Herzegovina'),
(7, 'Brazil'),
(36, 'Chile'),
(14, 'China'),
(29, 'Colombia'),
(1, 'Croatia'),
(19, 'Denmark'),
(3, 'France'),
(22, 'Germany'),
(13, 'Hungary'),
(2, 'Italy'),
(44, 'Jamaica'),
(42, 'Kenya'),
(43, 'Lebanon'),
(31, 'Marocco'),
(5, 'Mexico'),
(11, 'Montenegro'),
(41, 'Namibia'),
(18, 'New Zeland'),
(40, 'Nigeria'),
(35, 'North Korea'),
(25, 'Portugal'),
(27, 'Russia'),
(9, 'Saudi Arabia'),
(10, 'Serbia'),
(33, 'South Africa'),
(34, 'South Korea'),
(23, 'Spain'),
(15, 'Taiwan'),
(24, 'Thailand'),
(8, 'Ukraine'),
(20, 'United Kingdom'),
(6, 'Uruguay'),
(4, 'USA'),
(28, 'Venezuela'),
(21, 'Wales');

--
-- Triggers `state`
--
DROP TRIGGER IF EXISTS `UserLogAfterDeleteOnState`;
DELIMITER $$
CREATE TRIGGER `UserLogAfterDeleteOnState` AFTER DELETE ON `state` FOR EACH ROW begin 
call saveLog('delete','state');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `UserLogAfterInsertOnState`;
DELIMITER $$
CREATE TRIGGER `UserLogAfterInsertOnState` AFTER INSERT ON `state` FOR EACH ROW begin 
call saveLog('insert','state');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `UserLogAfterUpdateOnState`;
DELIMITER $$
CREATE TRIGGER `UserLogAfterUpdateOnState` AFTER UPDATE ON `state` FOR EACH ROW begin 
call saveLog('update','state');
end
$$
DELIMITER ;
