
-- --------------------------------------------------------

--
-- Table structure for table `imagedetails`
--
-- Creation: Jan 10, 2026 at 09:07 PM
--

DROP TABLE IF EXISTS `imagedetails`;
CREATE TABLE `imagedetails` (
  `iDetailsId` int(10) UNSIGNED NOT NULL,
  `typeId` int(10) UNSIGNED NOT NULL,
  `imageSize` varchar(15) NOT NULL,
  `imageDateAdded` datetime NOT NULL,
  `imageDateUpdated` datetime NOT NULL,
  `imageId` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `imagedetails`:
--   `imageId`
--       `image` -> `imageId`
--   `typeId`
--       `imagetype` -> `typeId`
--

--
-- Triggers `imagedetails`
--
DROP TRIGGER IF EXISTS `ImageDetailsLogAfterDelete`;
DELIMITER $$
CREATE TRIGGER `ImageDetailsLogAfterDelete` AFTER DELETE ON `imagedetails` FOR EACH ROW begin 
call saveLog('delete','imgdet');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `ImageDetailsLogAfterInsert`;
DELIMITER $$
CREATE TRIGGER `ImageDetailsLogAfterInsert` AFTER INSERT ON `imagedetails` FOR EACH ROW begin 
call saveLog('insert','imgdet');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `ImageDetailsLogAfterUpdate`;
DELIMITER $$
CREATE TRIGGER `ImageDetailsLogAfterUpdate` AFTER UPDATE ON `imagedetails` FOR EACH ROW begin 
call saveLog('update','imgdet');
end
$$
DELIMITER ;
