
-- --------------------------------------------------------

--
-- Table structure for table `state`
--
-- Creation: Jan 10, 2026 at 09:06 PM
--

DROP TABLE IF EXISTS `state`;
CREATE TABLE `state` (
  `stateId` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `state`:
--

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`stateId`, `name`) VALUES
(48, 'Afghanistan'),
(41, 'Algeria'),
(46, 'Angola'),
(35, 'Argentina'),
(26, 'Australia'),
(47, 'Austria'),
(25, 'Bangladesh'),
(39, 'Barbados'),
(54, 'Bosnia & Herzegovina'),
(21, 'Bosnia and Herzegovina'),
(16, 'Brazil'),
(65, 'Canada'),
(45, 'Chile'),
(23, 'China'),
(55, 'Cnd'),
(38, 'Colombia'),
(10, 'Croatia'),
(28, 'Denmark'),
(12, 'France'),
(31, 'Germany'),
(22, 'Hungary'),
(11, 'Italy'),
(51, 'Kenya'),
(53, 'Kosovo'),
(40, 'Marocco'),
(14, 'Mexico'),
(20, 'Montenegro'),
(50, 'Namibia'),
(27, 'New Zeland'),
(49, 'Nigeria'),
(34, 'Portugal'),
(52, 'Qatar'),
(36, 'Russia'),
(18, 'Saudi Arabia'),
(19, 'Serbia'),
(42, 'South Africa'),
(43, 'South Korea'),
(32, 'Spain'),
(24, 'Taiwan'),
(33, 'Thailand'),
(17, 'Ukraine'),
(29, 'United Kingdom'),
(15, 'Uruguay'),
(13, 'USA'),
(37, 'Venezuela'),
(30, 'Wales');

--
-- Triggers `state`
--
DROP TRIGGER IF EXISTS `UserLogAfterDeleteOnState`;
DELIMITER $$
CREATE TRIGGER `UserLogAfterDeleteOnState` AFTER DELETE ON `state` FOR EACH ROW begin 
call saveLog('delete','state');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `UserLogAfterInsertOnState`;
DELIMITER $$
CREATE TRIGGER `UserLogAfterInsertOnState` AFTER INSERT ON `state` FOR EACH ROW begin 
call saveLog('insert','state');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `UserLogAfterUpdateOnState`;
DELIMITER $$
CREATE TRIGGER `UserLogAfterUpdateOnState` AFTER UPDATE ON `state` FOR EACH ROW begin 
call saveLog('update','state');
end
$$
DELIMITER ;
