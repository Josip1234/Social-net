
--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounttype`
--
ALTER TABLE `accounttype`
  ADD PRIMARY KEY (`acTypeId`),
  ADD UNIQUE KEY `acTypeName` (`acTypeName`),
  ADD UNIQUE KEY `listOfPrivileges` (`listOfPrivileges`) USING HASH;

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`addressId`),
  ADD KEY `postNumber_fk` (`postNumber`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`postNumber`),
  ADD KEY `stateId_fk` (`stateId`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentId`);

--
-- Indexes for table `databaseuser`
--
ALTER TABLE `databaseuser`
  ADD PRIMARY KEY (`userId`),
  ADD UNIQUE KEY `userName` (`userName`),
  ADD KEY `accountType_fk` (`acTypeId`);

--
-- Indexes for table `database_logger`
--
ALTER TABLE `database_logger`
  ADD PRIMARY KEY (`dbLogId`),
  ADD KEY `user_id_fk` (`userId`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`imageId`),
  ADD UNIQUE KEY `url` (`url`) USING HASH,
  ADD KEY `userid_imgid_fk` (`userId`);

--
-- Indexes for table `imagedetails`
--
ALTER TABLE `imagedetails`
  ADD PRIMARY KEY (`iDetailsId`),
  ADD KEY `typeId_fk` (`typeId`),
  ADD KEY `imageId_fk` (`imageId`);

--
-- Indexes for table `imagetype`
--
ALTER TABLE `imagetype`
  ADD PRIMARY KEY (`typeId`),
  ADD UNIQUE KEY `iTypeName` (`iTypeName`);

--
-- Indexes for table `image_gallery`
--
ALTER TABLE `image_gallery`
  ADD PRIMARY KEY (`galleryId`),
  ADD UNIQUE KEY `galleryName` (`galleryName`);

--
-- Indexes for table `img_img_gal`
--
ALTER TABLE `img_img_gal`
  ADD PRIMARY KEY (`uniqueId`),
  ADD KEY `imageIdiig_fk` (`imageId`),
  ADD KEY `galleryId_fk` (`galleryId`);

--
-- Indexes for table `logger_content`
--
ALTER TABLE `logger_content`
  ADD PRIMARY KEY (`idLogCon`),
  ADD KEY `dbLogId_fk` (`dbLogId`);

--
-- Indexes for table `procomsub`
--
ALTER TABLE `procomsub`
  ADD PRIMARY KEY (`proComSub`),
  ADD KEY `userIdPcs_fk` (`userId`),
  ADD KEY `commentId_fk` (`commentId`),
  ADD KEY `subtopicsid_pcs_fk` (`subTopicsId`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`userId`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `addressId_fk` (`addressId`);

--
-- Indexes for table `profiledetails`
--
ALTER TABLE `profiledetails`
  ADD PRIMARY KEY (`proDetId`),
  ADD KEY `userIdac_fk` (`userId`),
  ADD KEY `acTypeId_fk` (`acTypeId`);

--
-- Indexes for table `profile_logger`
--
ALTER TABLE `profile_logger`
  ADD PRIMARY KEY (`plId`),
  ADD KEY `userIdpl_fk` (`userId`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`stateId`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `subtopics`
--
ALTER TABLE `subtopics`
  ADD PRIMARY KEY (`subTopicsId`),
  ADD UNIQUE KEY `subTopicContent` (`subTopicContent`) USING HASH,
  ADD KEY `topicId_fk` (`topicId`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`topicId`),
  ADD UNIQUE KEY `topicContent` (`topicContent`) USING HASH,
  ADD KEY `user_id_topics_fk` (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounttype`
--
ALTER TABLE `accounttype`
  MODIFY `acTypeId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `addressId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `databaseuser`
--
ALTER TABLE `databaseuser`
  MODIFY `userId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `database_logger`
--
ALTER TABLE `database_logger`
  MODIFY `dbLogId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `imageId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `imagedetails`
--
ALTER TABLE `imagedetails`
  MODIFY `iDetailsId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `imagetype`
--
ALTER TABLE `imagetype`
  MODIFY `typeId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `image_gallery`
--
ALTER TABLE `image_gallery`
  MODIFY `galleryId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `img_img_gal`
--
ALTER TABLE `img_img_gal`
  MODIFY `uniqueId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `logger_content`
--
ALTER TABLE `logger_content`
  MODIFY `idLogCon` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `procomsub`
--
ALTER TABLE `procomsub`
  MODIFY `proComSub` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `userId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `profiledetails`
--
ALTER TABLE `profiledetails`
  MODIFY `proDetId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profile_logger`
--
ALTER TABLE `profile_logger`
  MODIFY `plId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `stateId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `subtopics`
--
ALTER TABLE `subtopics`
  MODIFY `subTopicsId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `topicId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `postNumber_fk` FOREIGN KEY (`postNumber`) REFERENCES `city` (`postNumber`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `city`
--
ALTER TABLE `city`
  ADD CONSTRAINT `stateId_fk` FOREIGN KEY (`stateId`) REFERENCES `state` (`stateId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `databaseuser`
--
ALTER TABLE `databaseuser`
  ADD CONSTRAINT `accountType_fk` FOREIGN KEY (`acTypeId`) REFERENCES `accounttype` (`acTypeId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `database_logger`
--
ALTER TABLE `database_logger`
  ADD CONSTRAINT `user_id_fk` FOREIGN KEY (`userId`) REFERENCES `databaseuser` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `userid_imgid_fk` FOREIGN KEY (`userId`) REFERENCES `profile` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `imagedetails`
--
ALTER TABLE `imagedetails`
  ADD CONSTRAINT `imageId_fk` FOREIGN KEY (`imageId`) REFERENCES `image` (`imageId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `imagetype` (`typeId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `img_img_gal`
--
ALTER TABLE `img_img_gal`
  ADD CONSTRAINT `galleryId_fk` FOREIGN KEY (`galleryId`) REFERENCES `image_gallery` (`galleryId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `imageIdiig_fk` FOREIGN KEY (`imageId`) REFERENCES `image` (`imageId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `logger_content`
--
ALTER TABLE `logger_content`
  ADD CONSTRAINT `dbLogId_fk` FOREIGN KEY (`dbLogId`) REFERENCES `database_logger` (`dbLogId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `procomsub`
--
ALTER TABLE `procomsub`
  ADD CONSTRAINT `commentId_fk` FOREIGN KEY (`commentId`) REFERENCES `comments` (`commentId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `subtopicsid_pcs_fk` FOREIGN KEY (`subTopicsId`) REFERENCES `subtopics` (`subTopicsId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `userIdPcs_fk` FOREIGN KEY (`userId`) REFERENCES `profile` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `addressId_fk` FOREIGN KEY (`addressId`) REFERENCES `address` (`addressId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profiledetails`
--
ALTER TABLE `profiledetails`
  ADD CONSTRAINT `acTypeId_fk` FOREIGN KEY (`acTypeId`) REFERENCES `accounttype` (`acTypeId`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `userIdac_fk` FOREIGN KEY (`userId`) REFERENCES `profile` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile_logger`
--
ALTER TABLE `profile_logger`
  ADD CONSTRAINT `userIdpl_fk` FOREIGN KEY (`userId`) REFERENCES `profile` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subtopics`
--
ALTER TABLE `subtopics`
  ADD CONSTRAINT `topicId_fk` FOREIGN KEY (`topicId`) REFERENCES `topics` (`topicId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `topics`
--
ALTER TABLE `topics`
  ADD CONSTRAINT `user_id_topics_fk` FOREIGN KEY (`userId`) REFERENCES `profile` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;
