
-- --------------------------------------------------------

--
-- Table structure for table `database_logger`
--
-- Creation: Jan 10, 2026 at 09:07 PM
--

DROP TABLE IF EXISTS `database_logger`;
CREATE TABLE `database_logger` (
  `dbLogId` int(10) UNSIGNED NOT NULL,
  `userId` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `database_logger`:
--   `userId`
--       `databaseuser` -> `userId`
--

--
-- Dumping data for table `database_logger`
--

INSERT INTO `database_logger` (`dbLogId`, `userId`) VALUES
(1, 8),
(2, 9),
(5, 10),
(6, 11);

--
-- Triggers `database_logger`
--
DROP TRIGGER IF EXISTS `databaseLogAfterDelete`;
DELIMITER $$
CREATE TRIGGER `databaseLogAfterDelete` AFTER DELETE ON `database_logger` FOR EACH ROW begin 
call saveLog('delete','dblog');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `databaseLogAfterInsert`;
DELIMITER $$
CREATE TRIGGER `databaseLogAfterInsert` AFTER INSERT ON `database_logger` FOR EACH ROW begin 
call saveLog('insert','dblog');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `databaseLogAfterUpdate`;
DELIMITER $$
CREATE TRIGGER `databaseLogAfterUpdate` AFTER UPDATE ON `database_logger` FOR EACH ROW begin 
call saveLog('update','dblog');
end
$$
DELIMITER ;
