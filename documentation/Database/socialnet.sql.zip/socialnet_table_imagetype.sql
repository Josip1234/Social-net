
-- --------------------------------------------------------

--
-- Table structure for table `imagetype`
--
-- Creation: Jan 10, 2026 at 09:07 PM
--

DROP TABLE IF EXISTS `imagetype`;
CREATE TABLE `imagetype` (
  `typeId` int(10) UNSIGNED NOT NULL,
  `iTypeName` enum('.jpg','.jpeg','.png','.gif','.webp','.svg') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `imagetype`:
--

--
-- Triggers `imagetype`
--
DROP TRIGGER IF EXISTS `limitUserOfDeletingDataToImageType`;
DELIMITER $$
CREATE TRIGGER `limitUserOfDeletingDataToImageType` BEFORE DELETE ON `imagetype` FOR EACH ROW begin 
call limitUseOfCudOperations('delete');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `limitUserOfInsertingDataToImageType`;
DELIMITER $$
CREATE TRIGGER `limitUserOfInsertingDataToImageType` BEFORE INSERT ON `imagetype` FOR EACH ROW begin 
call limitUseOfCudOperations('insert');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `limitUserOfUpdatingDataToImageType`;
DELIMITER $$
CREATE TRIGGER `limitUserOfUpdatingDataToImageType` BEFORE UPDATE ON `imagetype` FOR EACH ROW begin 
call limitUseOfCudOperations('update');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logImageTypeAfterDelete`;
DELIMITER $$
CREATE TRIGGER `logImageTypeAfterDelete` AFTER DELETE ON `imagetype` FOR EACH ROW begin 
call saveLog('delete','imgtyp');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logImageTypeAfterInsert`;
DELIMITER $$
CREATE TRIGGER `logImageTypeAfterInsert` AFTER INSERT ON `imagetype` FOR EACH ROW begin 
call saveLog('insert','imgtyp');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logImageTypeAfterUpdate`;
DELIMITER $$
CREATE TRIGGER `logImageTypeAfterUpdate` AFTER UPDATE ON `imagetype` FOR EACH ROW begin 
call saveLog('update','imgtyp');
end
$$
DELIMITER ;
