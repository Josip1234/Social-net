
-- --------------------------------------------------------

--
-- Table structure for table `image`
--
-- Creation: Jan 10, 2026 at 09:07 PM
--

DROP TABLE IF EXISTS `image`;
CREATE TABLE `image` (
  `imageId` int(10) UNSIGNED NOT NULL,
  `userId` int(10) UNSIGNED NOT NULL,
  `imageName` varchar(50) NOT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `image`:
--   `userId`
--       `profile` -> `userId`
--

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`imageId`, `userId`, `imageName`, `url`) VALUES
(1, 2, 'slikica.jpg', 'www.google.com/slikica.jpg'),
(2, 2, 'slikic1a.jpg', 'www.googl1e.com/slikica.jpg');

--
-- Triggers `image`
--
DROP TRIGGER IF EXISTS `ImageLogAfterDelete`;
DELIMITER $$
CREATE TRIGGER `ImageLogAfterDelete` AFTER DELETE ON `image` FOR EACH ROW begin 
call saveLog('delete','img');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `ImageLogAfterInsert`;
DELIMITER $$
CREATE TRIGGER `ImageLogAfterInsert` AFTER INSERT ON `image` FOR EACH ROW begin 
call saveLog('insert','img');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `ImageLogAfterUpdate`;
DELIMITER $$
CREATE TRIGGER `ImageLogAfterUpdate` AFTER UPDATE ON `image` FOR EACH ROW begin 
call saveLog('update','img');
end
$$
DELIMITER ;
