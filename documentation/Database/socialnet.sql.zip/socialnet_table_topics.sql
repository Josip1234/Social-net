
-- --------------------------------------------------------

--
-- Table structure for table `topics`
--
-- Creation: Jan 10, 2026 at 09:08 PM
-- Last update: Jan 16, 2026 at 08:13 AM
--

DROP TABLE IF EXISTS `topics`;
CREATE TABLE `topics` (
  `topicId` int(10) UNSIGNED NOT NULL,
  `userId` int(10) UNSIGNED NOT NULL,
  `topicContent` text NOT NULL,
  `topicDateAdded` datetime NOT NULL,
  `topicLike` int(10) UNSIGNED NOT NULL,
  `topicDislike` int(10) UNSIGNED NOT NULL,
  `topicDateUpdated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `topics`:
--   `userId`
--       `profile` -> `userId`
--

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`topicId`, `userId`, `topicContent`, `topicDateAdded`, `topicLike`, `topicDislike`, `topicDateUpdated`) VALUES
(1, 2, 'Fašizam u Americi', '2026-01-14 09:01:57', 1, 0, '2026-01-16 09:12:14'),
(2, 2, 'Nova tema', '2026-01-16 08:55:04', 0, 0, '0000-00-00 00:00:00');

--
-- Triggers `topics`
--
DROP TRIGGER IF EXISTS `logContentAfterDeleteTop`;
DELIMITER $$
CREATE TRIGGER `logContentAfterDeleteTop` AFTER DELETE ON `topics` FOR EACH ROW begin 
call saveLog2('delete','top');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logContentAfterInsertTop`;
DELIMITER $$
CREATE TRIGGER `logContentAfterInsertTop` AFTER INSERT ON `topics` FOR EACH ROW begin 
call saveLog2('insert','top');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logContentAfterUpdateTop`;
DELIMITER $$
CREATE TRIGGER `logContentAfterUpdateTop` AFTER UPDATE ON `topics` FOR EACH ROW begin 
call saveLog2('update','top');
end
$$
DELIMITER ;
