
-- --------------------------------------------------------

--
-- Table structure for table `profile`
--
-- Creation: Jan 10, 2026 at 09:06 PM
--

DROP TABLE IF EXISTS `profile`;
CREATE TABLE `profile` (
  `userId` int(10) UNSIGNED NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `sex` char(1) NOT NULL,
  `dateOfBirth` date NOT NULL,
  `addressId` int(10) UNSIGNED DEFAULT NULL,
  `hashPassword` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `profile`:
--   `addressId`
--       `address` -> `addressId`
--

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`userId`, `firstName`, `lastName`, `email`, `sex`, `dateOfBirth`, `addressId`, `hashPassword`) VALUES
(2, 'Josip', 'Bošnjak', 'jbosnjak@mail.com', 'm', '1992-11-05', 1, '789b49606c321c8cf228d17942608eff0ccc4171');

--
-- Triggers `profile`
--
DROP TRIGGER IF EXISTS `userDeleteProfileLog`;
DELIMITER $$
CREATE TRIGGER `userDeleteProfileLog` AFTER DELETE ON `profile` FOR EACH ROW begin 
call saveProfileLog('delete','profile',concat(old.firstName,' ',old.lastName),null);
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `userProfileLog`;
DELIMITER $$
CREATE TRIGGER `userProfileLog` AFTER INSERT ON `profile` FOR EACH ROW begin 
call saveProfileLog('insert','profile',concat(new.firstName,' ',new.lastName),null);
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `userUpdateProfileLog`;
DELIMITER $$
CREATE TRIGGER `userUpdateProfileLog` AFTER UPDATE ON `profile` FOR EACH ROW begin 
call saveProfileLog('update','profile',concat(new.firstName,' ',new.lastName),concat(old.firstName,' ',old.lastName));
end
$$
DELIMITER ;
