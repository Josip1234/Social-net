
-- --------------------------------------------------------

--
-- Table structure for table `profiledetails`
--
-- Creation: Jan 10, 2026 at 09:06 PM
--

DROP TABLE IF EXISTS `profiledetails`;
CREATE TABLE `profiledetails` (
  `proDetId` int(10) UNSIGNED NOT NULL,
  `userId` int(10) UNSIGNED NOT NULL,
  `acTypeId` int(10) UNSIGNED DEFAULT NULL,
  `registrationDate` datetime NOT NULL,
  `pdUpdateDate` datetime NOT NULL,
  `accountStatus` enum('Active','Banned','Inactive') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `profiledetails`:
--   `acTypeId`
--       `accounttype` -> `acTypeId`
--   `userId`
--       `profile` -> `userId`
--

--
-- Triggers `profiledetails`
--
DROP TRIGGER IF EXISTS `addedProfileDetailsLog`;
DELIMITER $$
CREATE TRIGGER `addedProfileDetailsLog` AFTER INSERT ON `profiledetails` FOR EACH ROW begin 
call saveLog('insert','pd');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `deletedProfileDetailsLog`;
DELIMITER $$
CREATE TRIGGER `deletedProfileDetailsLog` AFTER DELETE ON `profiledetails` FOR EACH ROW begin 
call saveLog('delete','pd');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `updatedProfileDetailsLog`;
DELIMITER $$
CREATE TRIGGER `updatedProfileDetailsLog` AFTER UPDATE ON `profiledetails` FOR EACH ROW begin 
call saveLog('update','pd');
end
$$
DELIMITER ;
