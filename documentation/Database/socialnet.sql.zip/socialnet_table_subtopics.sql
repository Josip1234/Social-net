
-- --------------------------------------------------------

--
-- Table structure for table `subtopics`
--
-- Creation: Jan 10, 2026 at 09:08 PM
-- Last update: Jan 16, 2026 at 08:02 AM
--

DROP TABLE IF EXISTS `subtopics`;
CREATE TABLE `subtopics` (
  `subTopicsId` int(10) UNSIGNED NOT NULL,
  `topicId` int(10) UNSIGNED NOT NULL,
  `subTopicContent` text NOT NULL,
  `subTopicDateAdded` datetime NOT NULL,
  `subTopicDateUpdated` datetime NOT NULL,
  `subtopicLike` int(10) UNSIGNED NOT NULL,
  `subtopicDislike` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `subtopics`:
--   `topicId`
--       `topics` -> `topicId`
--

--
-- Dumping data for table `subtopics`
--

INSERT INTO `subtopics` (`subTopicsId`, `topicId`, `subTopicContent`, `subTopicDateAdded`, `subTopicDateUpdated`, `subtopicLike`, `subtopicDislike`) VALUES
(2, 1, 'Nova podtema', '2026-01-16 08:57:04', '2026-01-16 09:01:06', 0, 0);

--
-- Triggers `subtopics`
--
DROP TRIGGER IF EXISTS `logContentAfterDeleteSt`;
DELIMITER $$
CREATE TRIGGER `logContentAfterDeleteSt` AFTER DELETE ON `subtopics` FOR EACH ROW begin 
call saveLog2('delete','st');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logContentAfterInsertSt`;
DELIMITER $$
CREATE TRIGGER `logContentAfterInsertSt` AFTER INSERT ON `subtopics` FOR EACH ROW begin 
call saveLog2('insert','st');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logContentAfterUpdateSt`;
DELIMITER $$
CREATE TRIGGER `logContentAfterUpdateSt` AFTER UPDATE ON `subtopics` FOR EACH ROW begin 
call saveLog2('update','st');
end
$$
DELIMITER ;
