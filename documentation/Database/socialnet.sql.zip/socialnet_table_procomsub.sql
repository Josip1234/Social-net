
-- --------------------------------------------------------

--
-- Table structure for table `procomsub`
--
-- Creation: Jan 10, 2026 at 09:08 PM
--

DROP TABLE IF EXISTS `procomsub`;
CREATE TABLE `procomsub` (
  `proComSub` int(10) UNSIGNED NOT NULL,
  `userId` int(10) UNSIGNED NOT NULL,
  `commentId` int(10) UNSIGNED NOT NULL,
  `subTopicsId` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `procomsub`:
--   `commentId`
--       `comments` -> `commentId`
--   `subTopicsId`
--       `subtopics` -> `subTopicsId`
--   `userId`
--       `profile` -> `userId`
--

--
-- Triggers `procomsub`
--
DROP TRIGGER IF EXISTS `proComSubLogAfterDelete`;
DELIMITER $$
CREATE TRIGGER `proComSubLogAfterDelete` AFTER DELETE ON `procomsub` FOR EACH ROW begin 
call saveLog('delete','pcs');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `proComSubLogAfterInsert`;
DELIMITER $$
CREATE TRIGGER `proComSubLogAfterInsert` AFTER INSERT ON `procomsub` FOR EACH ROW begin 
call saveLog('insert','pcs');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `proComSubLogAfterUpdate`;
DELIMITER $$
CREATE TRIGGER `proComSubLogAfterUpdate` AFTER UPDATE ON `procomsub` FOR EACH ROW begin 
call saveLog('update','pcs');
end
$$
DELIMITER ;
