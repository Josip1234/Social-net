
-- --------------------------------------------------------

--
-- Table structure for table `accounttype`
--
-- Creation: Jan 10, 2026 at 09:06 PM
--

DROP TABLE IF EXISTS `accounttype`;
CREATE TABLE `accounttype` (
  `acTypeId` int(10) UNSIGNED NOT NULL,
  `acTypeName` varchar(30) NOT NULL,
  `listOfPrivileges` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `accounttype`:
--

--
-- Dumping data for table `accounttype`
--

INSERT INTO `accounttype` (`acTypeId`, `acTypeName`, `listOfPrivileges`) VALUES
(1, 'Admin', 'ALL PRIVILEGES'),
(2, 'Regular', 'Create,insert,delete,select'),
(3, 'Banned', 'Account is locked'),
(4, 'B', 'Accountis locked');

--
-- Triggers `accounttype`
--
DROP TRIGGER IF EXISTS `deleteTypeLog`;
DELIMITER $$
CREATE TRIGGER `deleteTypeLog` AFTER DELETE ON `accounttype` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000'
set message_text='User is not admin. Operation not allowed.';
else
call saveLog('delete','at');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `insertTypeLog`;
DELIMITER $$
CREATE TRIGGER `insertTypeLog` AFTER INSERT ON `accounttype` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000'
set message_text='User is not admin. Operation not allowed.';
else
call saveLog('insert','at');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `limitAccountTypeTableBeforeDelete`;
DELIMITER $$
CREATE TRIGGER `limitAccountTypeTableBeforeDelete` BEFORE DELETE ON `accounttype` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000'
set message_text='User is not admin. Operation not allowed.';
else
call limitUseOfCudOperations('delete');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `limitAccountTypeTableBeforeInsert`;
DELIMITER $$
CREATE TRIGGER `limitAccountTypeTableBeforeInsert` BEFORE INSERT ON `accounttype` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000'
set message_text='User is not admin. Operation not allowed.';
else
call limitUseOfCudOperations('insert');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `limitAccountTypeTableBeforeUpdate`;
DELIMITER $$
CREATE TRIGGER `limitAccountTypeTableBeforeUpdate` BEFORE UPDATE ON `accounttype` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000'
set message_text='User is not admin. Operation not allowed.';
else
call limitUseOfCudOperations('update');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `updateTypeLog`;
DELIMITER $$
CREATE TRIGGER `updateTypeLog` AFTER UPDATE ON `accounttype` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000'
set message_text='User is not admin. Operation not allowed.';
else
call saveLog('update','at');
end if;
end
$$
DELIMITER ;
