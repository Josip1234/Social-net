
-- --------------------------------------------------------

--
-- Table structure for table `logger_content`
--
-- Creation: Jan 10, 2026 at 09:08 PM
-- Last update: Jan 16, 2026 at 08:13 AM
--

DROP TABLE IF EXISTS `logger_content`;
CREATE TABLE `logger_content` (
  `idLogCon` int(10) UNSIGNED NOT NULL,
  `dbLogId` int(10) UNSIGNED NOT NULL,
  `loggerDescription` text NOT NULL,
  `userAdded` varchar(255) NOT NULL,
  `userUpdated` varchar(255) DEFAULT NULL,
  `userDeleted` varchar(255) DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateUpdated` datetime DEFAULT NULL,
  `dateAdded` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `logger_content`:
--   `dbLogId`
--       `database_logger` -> `dbLogId`
--

--
-- Dumping data for table `logger_content`
--

INSERT INTO `logger_content` (`idLogCon`, `dbLogId`, `loggerDescription`, `userAdded`, `userUpdated`, `userDeleted`, `dateDeleted`, `dateUpdated`, `dateAdded`) VALUES
(4, 2, 'Logged in user has added new state', 'social_admin', NULL, NULL, NULL, NULL, '2026-01-15 09:35:43'),
(7, 2, 'New user has been added to profile logger.', 'social_admin', NULL, NULL, NULL, NULL, '2026-01-15 10:16:55'),
(8, 2, 'User has been updated from profile logger', '', 'social_admin', NULL, NULL, '2026-01-15 10:16:55', '0000-00-00 00:00:00'),
(9, 2, 'User has been deleted from profile logger.', '', NULL, 'social_admin', '2026-01-15 10:18:33', NULL, '0000-00-00 00:00:00'),
(10, 2, 'New user has been added to database logger.', 'social_admin', NULL, NULL, NULL, NULL, '2026-01-15 10:50:23'),
(11, 2, 'New database user has been added.', 'social_admin', NULL, NULL, NULL, NULL, '2026-01-15 10:54:00'),
(12, 2, 'New user has been added to database logger.', 'social_admin', NULL, NULL, NULL, NULL, '2026-01-15 10:54:00'),
(13, 2, 'New database user has been added.', 'social_admin', NULL, NULL, NULL, NULL, '2026-01-15 10:54:00'),
(14, 2, 'New subtopic has been added.', 'social_admin', NULL, NULL, NULL, NULL, '2026-01-16 08:57:04'),
(15, 2, 'Subtopic has been updated.', '', 'social_admin', NULL, NULL, '2026-01-16 09:01:06', '0000-00-00 00:00:00'),
(16, 2, 'Subtopic has been deleted.', '', NULL, 'social_admin', '2026-01-16 09:02:06', NULL, '0000-00-00 00:00:00'),
(17, 2, 'New topic has been added.', 'social_admin', NULL, NULL, NULL, NULL, '2026-01-16 09:10:28'),
(18, 2, 'Topic has been updated.', '', 'social_admin', NULL, NULL, '2026-01-16 09:12:14', '0000-00-00 00:00:00'),
(19, 2, 'Topic has been deleted.', '', NULL, 'social_admin', '2026-01-16 09:13:04', NULL, '0000-00-00 00:00:00');

--
-- Triggers `logger_content`
--
DROP TRIGGER IF EXISTS `logContentBeforeUpdate`;
DELIMITER $$
CREATE TRIGGER `logContentBeforeUpdate` BEFORE UPDATE ON `logger_content` FOR EACH ROW begin 
SIGNAL sqlstate '45000' 
set message_text='Update operation for update log content in logger content table is not allowed.';
end
$$
DELIMITER ;
