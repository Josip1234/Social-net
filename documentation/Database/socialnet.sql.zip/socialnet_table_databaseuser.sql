
-- --------------------------------------------------------

--
-- Table structure for table `databaseuser`
--
-- Creation: Jan 10, 2026 at 09:09 PM
--

DROP TABLE IF EXISTS `databaseuser`;
CREATE TABLE `databaseuser` (
  `userId` int(10) UNSIGNED NOT NULL,
  `userName` varchar(255) NOT NULL,
  `acTypeId` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `databaseuser`:
--   `acTypeId`
--       `accounttype` -> `acTypeId`
--

--
-- Dumping data for table `databaseuser`
--

INSERT INTO `databaseuser` (`userId`, `userName`, `acTypeId`) VALUES
(8, 'regular', 2),
(9, 'social_admin', 1),
(10, 'Someone new', 2),
(11, 'kontrola', 2);

--
-- Triggers `databaseuser`
--
DROP TRIGGER IF EXISTS `dbuserDeleteLog`;
DELIMITER $$
CREATE TRIGGER `dbuserDeleteLog` AFTER DELETE ON `databaseuser` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000' 
set message_text='User is not admin.Operation not allowed.';
	else
call saveLog('delete','dbus');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `dbuserInsertLog`;
DELIMITER $$
CREATE TRIGGER `dbuserInsertLog` BEFORE INSERT ON `databaseuser` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000' 
set message_text='User is not admin.Operation not allowed.';
	else
call saveLog('insert','dbus');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `dbuserUpdateLog`;
DELIMITER $$
CREATE TRIGGER `dbuserUpdateLog` AFTER UPDATE ON `databaseuser` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000' 
set message_text='User is not admin.Operation not allowed.';
	else
call saveLog('update','dbus');
end if;
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `insertUserIntoDatabaseLogger`;
DELIMITER $$
CREATE TRIGGER `insertUserIntoDatabaseLogger` AFTER INSERT ON `databaseuser` FOR EACH ROW begin 
if user()='regular' then
SIGNAL sqlstate '45000' 
set message_text='User is not admin.Operation not allowed.';
	else
call insertUsersIntoDbLoggerIfNotExists(new.userId);
end if;
end
$$
DELIMITER ;
