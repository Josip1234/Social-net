
-- --------------------------------------------------------

--
-- Table structure for table `address`
--
-- Creation: Jan 10, 2026 at 09:06 PM
--

DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `addressId` int(10) UNSIGNED NOT NULL,
  `street` varchar(255) NOT NULL,
  `postNumber` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `address`:
--   `postNumber`
--       `city` -> `postNumber`
--

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`addressId`, `street`, `postNumber`) VALUES
(1, 'Izmišljena ulica 53', '34000'),
(2, 'Izmišljena ulica 25', '34000'),
(3, 'Izmišljena uliva 55', '34000');

--
-- Triggers `address`
--
DROP TRIGGER IF EXISTS `deleteAdrIntoDatabaseLogger`;
DELIMITER $$
CREATE TRIGGER `deleteAdrIntoDatabaseLogger` AFTER DELETE ON `address` FOR EACH ROW begin 
call saveLog('delete','adr');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `insertAdrIntoDatabaseLogger`;
DELIMITER $$
CREATE TRIGGER `insertAdrIntoDatabaseLogger` AFTER INSERT ON `address` FOR EACH ROW begin 
call saveLog('insert','adr');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `updateAdrIntoDatabaseLogger`;
DELIMITER $$
CREATE TRIGGER `updateAdrIntoDatabaseLogger` AFTER UPDATE ON `address` FOR EACH ROW begin 
call saveLog('update','adr');
end
$$
DELIMITER ;
