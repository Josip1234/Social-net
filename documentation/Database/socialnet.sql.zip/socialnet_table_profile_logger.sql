
-- --------------------------------------------------------

--
-- Table structure for table `profile_logger`
--
-- Creation: Jan 10, 2026 at 09:08 PM
--

DROP TABLE IF EXISTS `profile_logger`;
CREATE TABLE `profile_logger` (
  `plId` int(10) UNSIGNED NOT NULL,
  `userId` int(10) UNSIGNED NOT NULL,
  `message` text NOT NULL,
  `additionDate` datetime NOT NULL,
  `updateDate` datetime DEFAULT NULL,
  `deleteDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `profile_logger`:
--   `userId`
--       `profile` -> `userId`
--

--
-- Triggers `profile_logger`
--
DROP TRIGGER IF EXISTS `logContentAfterDelete`;
DELIMITER $$
CREATE TRIGGER `logContentAfterDelete` AFTER DELETE ON `profile_logger` FOR EACH ROW begin 
call saveLog2('delete','pl');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logContentAfterUpdate`;
DELIMITER $$
CREATE TRIGGER `logContentAfterUpdate` AFTER INSERT ON `profile_logger` FOR EACH ROW begin 
call saveLog2('update','pl');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `logContentAfterinsert`;
DELIMITER $$
CREATE TRIGGER `logContentAfterinsert` AFTER INSERT ON `profile_logger` FOR EACH ROW begin 
call saveLog2('insert','pl');
end
$$
DELIMITER ;
