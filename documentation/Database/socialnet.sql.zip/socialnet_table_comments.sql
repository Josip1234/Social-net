
-- --------------------------------------------------------

--
-- Table structure for table `comments`
--
-- Creation: Jan 10, 2026 at 09:08 PM
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `commentId` int(10) UNSIGNED NOT NULL,
  `commentContent` text NOT NULL,
  `markOfOffensiveness` enum('Offensive','Not offensive') DEFAULT NULL,
  `comDateUpdated` datetime NOT NULL,
  `comDateAdded` datetime NOT NULL,
  `commentLike` int(10) UNSIGNED NOT NULL,
  `commentDislike` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `comments`:
--

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`commentId`, `commentContent`, `markOfOffensiveness`, `comDateUpdated`, `comDateAdded`, `commentLike`, `commentDislike`) VALUES
(2, 'Testni komentar', 'Not offensive', '0000-00-00 00:00:00', '2026-01-14 09:06:21', 0, 0),
(3, 'Fuck you DonaldTrump you nazi asshole!', 'Offensive', '0000-00-00 00:00:00', '2026-01-14 09:11:16', 0, 0);

--
-- Triggers `comments`
--
DROP TRIGGER IF EXISTS `CommentLogAfterDelete`;
DELIMITER $$
CREATE TRIGGER `CommentLogAfterDelete` AFTER DELETE ON `comments` FOR EACH ROW begin 
call saveLog('delete','cmt');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `CommentLogAfterInsert`;
DELIMITER $$
CREATE TRIGGER `CommentLogAfterInsert` AFTER INSERT ON `comments` FOR EACH ROW begin 
call saveLog('insert','cmt');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `CommentLogAfterUpdate`;
DELIMITER $$
CREATE TRIGGER `CommentLogAfterUpdate` AFTER UPDATE ON `comments` FOR EACH ROW begin 
call saveLog('update','cmt');
end
$$
DELIMITER ;
