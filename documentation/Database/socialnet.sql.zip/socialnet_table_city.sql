
-- --------------------------------------------------------

--
-- Table structure for table `city`
--
-- Creation: Jan 10, 2026 at 09:06 PM
--

DROP TABLE IF EXISTS `city`;
CREATE TABLE `city` (
  `postNumber` varchar(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `stateId` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `city`:
--   `stateId`
--       `state` -> `stateId`
--

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`postNumber`, `name`, `stateId`) VALUES
('10000', 'Zagreb', 10),
('34000', 'Požega', 10),
('35000', 'Slavonski Brod', 10);

--
-- Triggers `city`
--
DROP TRIGGER IF EXISTS `UserLogAfterDeleteOnCity`;
DELIMITER $$
CREATE TRIGGER `UserLogAfterDeleteOnCity` AFTER DELETE ON `city` FOR EACH ROW begin 
call saveLog('delete','city');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `UserLogAfterInsertOnCity`;
DELIMITER $$
CREATE TRIGGER `UserLogAfterInsertOnCity` AFTER INSERT ON `city` FOR EACH ROW begin 
call saveLog('insert','city');
end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `UserLogAfterUpdateOnCity`;
DELIMITER $$
CREATE TRIGGER `UserLogAfterUpdateOnCity` AFTER UPDATE ON `city` FOR EACH ROW begin 
call saveLog('update','city');
end
$$
DELIMITER ;
