
-- --------------------------------------------------------

--
-- Table structure for table `img_img_gal`
--
-- Creation: Dec 17, 2025 at 12:29 PM
--

DROP TABLE IF EXISTS `img_img_gal`;
CREATE TABLE IF NOT EXISTS `img_img_gal` (
  `uniqueId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `imageId` int(10) UNSIGNED NOT NULL,
  `galleryId` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`uniqueId`),
  KEY `imageIdiig_fk` (`imageId`),
  KEY `galleryId_fk` (`galleryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `img_img_gal`:
--   `galleryId`
--       `image_gallery` -> `galleryId`
--   `imageId`
--       `image` -> `imageId`
--
