
-- --------------------------------------------------------

--
-- Table structure for table `databaseuser`
--
-- Creation: Dec 11, 2025 at 04:20 PM
-- Last update: Dec 17, 2025 at 12:59 PM
--

DROP TABLE IF EXISTS `databaseuser`;
CREATE TABLE IF NOT EXISTS `databaseuser` (
  `userId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) NOT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `userName` (`userName`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `databaseuser`:
--

--
-- Dumping data for table `databaseuser`
--

INSERT INTO `databaseuser` (`userId`, `userName`) VALUES
(2, 'regular'),
(1, 'social_admin');
