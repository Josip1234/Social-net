
-- --------------------------------------------------------

--
-- Table structure for table `city`
--
-- Creation: Nov 27, 2025 at 08:17 PM
-- Last update: Nov 27, 2025 at 08:33 PM
--

DROP TABLE IF EXISTS `city`;
CREATE TABLE IF NOT EXISTS `city` (
  `postNumber` varchar(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `stateId` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`postNumber`),
  KEY `stateId_fk` (`stateId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `city`:
--   `stateId`
--       `state` -> `stateId`
--

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`postNumber`, `name`, `stateId`) VALUES
('10000', 'Zagreb', 1),
('10450', 'Jastrebarsko', 1),
('34000', 'Požega', 1),
('35000', 'Slavonski Brod', 1),
('44330', 'Novska', 1),
('47240', 'Slunj', 1);
