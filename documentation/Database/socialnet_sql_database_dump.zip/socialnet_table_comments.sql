
-- --------------------------------------------------------

--
-- Table structure for table `comments`
--
-- Creation: Dec 14, 2025 at 07:44 PM
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `commentId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `commentContent` text NOT NULL,
  `markOfOffensiveness` enum('Offensive','Not offensive') DEFAULT NULL,
  `comDateUpdated` datetime NOT NULL,
  `comDateAdded` datetime NOT NULL,
  `commentLike` int(10) UNSIGNED NOT NULL,
  `commentDislike` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`commentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `comments`:
--
