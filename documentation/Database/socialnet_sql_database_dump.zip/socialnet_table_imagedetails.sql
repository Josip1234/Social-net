
-- --------------------------------------------------------

--
-- Table structure for table `imagedetails`
--
-- Creation: Nov 30, 2025 at 02:28 PM
--

DROP TABLE IF EXISTS `imagedetails`;
CREATE TABLE IF NOT EXISTS `imagedetails` (
  `iDetailsId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `typeId` int(10) UNSIGNED NOT NULL,
  `imageSize` varchar(15) NOT NULL,
  `imageDateAdded` datetime NOT NULL,
  `imageDateUpdated` datetime NOT NULL,
  `imageId` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`iDetailsId`),
  KEY `typeId_fk` (`typeId`),
  KEY `imageId_fk` (`imageId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `imagedetails`:
--   `imageId`
--       `image` -> `imageId`
--   `typeId`
--       `imagetype` -> `typeId`
--

--
-- Dumping data for table `imagedetails`
--

INSERT INTO `imagedetails` (`iDetailsId`, `typeId`, `imageSize`, `imageDateAdded`, `imageDateUpdated`, `imageId`) VALUES
(1, 1, '16 kb', '2025-11-30 15:29:10', '2025-11-30 15:29:10', 1);
