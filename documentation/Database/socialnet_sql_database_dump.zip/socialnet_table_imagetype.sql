
-- --------------------------------------------------------

--
-- Table structure for table `imagetype`
--
-- Creation: Nov 30, 2025 at 08:55 AM
--

DROP TABLE IF EXISTS `imagetype`;
CREATE TABLE IF NOT EXISTS `imagetype` (
  `typeId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `iTypeName` enum('.jpg','.jpeg','.png','.gif','.webp','.svg') DEFAULT NULL,
  PRIMARY KEY (`typeId`),
  UNIQUE KEY `iTypeName` (`iTypeName`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `imagetype`:
--

--
-- Dumping data for table `imagetype`
--

INSERT INTO `imagetype` (`typeId`, `iTypeName`) VALUES
(1, '.jpg'),
(2, '.jpeg'),
(3, '.png'),
(4, '.gif'),
(5, '.webp'),
(6, '.svg');
