
-- --------------------------------------------------------

--
-- Table structure for table `profile`
--
-- Creation: Nov 28, 2025 at 11:23 AM
--

DROP TABLE IF EXISTS `profile`;
CREATE TABLE IF NOT EXISTS `profile` (
  `userId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `sex` char(1) NOT NULL,
  `dateOfBirth` date NOT NULL,
  `addressId` int(10) UNSIGNED DEFAULT NULL,
  `hashPassword` text NOT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `email` (`email`),
  KEY `addressId_fk` (`addressId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `profile`:
--   `addressId`
--       `address` -> `addressId`
--
