
-- --------------------------------------------------------

--
-- Table structure for table `profile_logger`
--
-- Creation: Dec 17, 2025 at 12:12 PM
--

DROP TABLE IF EXISTS `profile_logger`;
CREATE TABLE IF NOT EXISTS `profile_logger` (
  `plId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userId` int(10) UNSIGNED NOT NULL,
  `message` text NOT NULL,
  `additionDate` datetime NOT NULL,
  `updateDate` datetime DEFAULT NULL,
  `deleteDate` datetime DEFAULT NULL,
  PRIMARY KEY (`plId`),
  KEY `userIdpl_fk` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `profile_logger`:
--   `userId`
--       `profile` -> `userId`
--
