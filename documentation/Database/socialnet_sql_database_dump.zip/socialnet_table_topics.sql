
-- --------------------------------------------------------

--
-- Table structure for table `topics`
--
-- Creation: Dec 14, 2025 at 07:33 PM
--

DROP TABLE IF EXISTS `topics`;
CREATE TABLE IF NOT EXISTS `topics` (
  `topicId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userId` int(10) UNSIGNED NOT NULL,
  `topicContent` text NOT NULL,
  `topicDateAdded` datetime NOT NULL,
  `topicLike` int(10) UNSIGNED NOT NULL,
  `topicDislike` int(10) UNSIGNED NOT NULL,
  `topicDateUpdated` datetime NOT NULL,
  PRIMARY KEY (`topicId`),
  UNIQUE KEY `topicContent` (`topicContent`) USING HASH,
  KEY `user_id_topics_fk` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `topics`:
--   `userId`
--       `profile` -> `userId`
--
