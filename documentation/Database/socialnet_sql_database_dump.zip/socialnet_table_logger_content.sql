
-- --------------------------------------------------------

--
-- Table structure for table `logger_content`
--
-- Creation: Dec 12, 2025 at 01:42 PM
--

DROP TABLE IF EXISTS `logger_content`;
CREATE TABLE IF NOT EXISTS `logger_content` (
  `idLogCon` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `dbLogId` int(10) UNSIGNED NOT NULL,
  `loggerDescription` text NOT NULL,
  `userAdded` varchar(255) NOT NULL,
  `userUpdated` varchar(255) DEFAULT NULL,
  `userDeleted` varchar(255) DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateUpdated` datetime DEFAULT NULL,
  `dateAdded` datetime NOT NULL,
  PRIMARY KEY (`idLogCon`),
  KEY `dbLogId_fk` (`dbLogId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `logger_content`:
--   `dbLogId`
--       `database_logger` -> `dbLogId`
--
