
-- --------------------------------------------------------

--
-- Table structure for table `image`
--
-- Creation: Nov 30, 2025 at 02:28 PM
--

DROP TABLE IF EXISTS `image`;
CREATE TABLE IF NOT EXISTS `image` (
  `imageId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userId` int(10) UNSIGNED NOT NULL,
  `imageName` varchar(50) NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`imageId`),
  UNIQUE KEY `url` (`url`) USING HASH,
  KEY `userid_imgid_fk` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `image`:
--   `userId`
--       `profile` -> `userId`
--

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`imageId`, `userId`, `imageName`, `url`) VALUES
(1, 1, 'Nova slika', 'www.localhost/image/image2.jpg');
