
-- --------------------------------------------------------

--
-- Table structure for table `address`
--
-- Creation: Nov 28, 2025 at 10:49 AM
--

DROP TABLE IF EXISTS `address`;
CREATE TABLE IF NOT EXISTS `address` (
  `addressId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `street` varchar(255) NOT NULL,
  `postNumber` varchar(20) NOT NULL,
  PRIMARY KEY (`addressId`),
  KEY `postNumber_fk` (`postNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `address`:
--   `postNumber`
--       `city` -> `postNumber`
--

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`addressId`, `street`, `postNumber`) VALUES
(1, 'Izmišljena ulica 53', '34000'),
(2, 'Izmišljena ulica 25', '34000'),
(3, 'Izmišljena uliva 55', '34000'),
(4, 'Izmišljena ulica 54', '10000'),
(5, 'Izmišljena ulica 25', '10450'),
(6, 'Izmišljena uliva 55', '44213');
