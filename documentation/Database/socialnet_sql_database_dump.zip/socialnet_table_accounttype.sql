
-- --------------------------------------------------------

--
-- Table structure for table `accounttype`
--
-- Creation: Nov 29, 2025 at 06:51 PM
--

DROP TABLE IF EXISTS `accounttype`;
CREATE TABLE IF NOT EXISTS `accounttype` (
  `acTypeId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `acTypeName` varchar(30) NOT NULL,
  `listOfPrivileges` text NOT NULL,
  PRIMARY KEY (`acTypeId`),
  UNIQUE KEY `acTypeName` (`acTypeName`),
  UNIQUE KEY `listOfPrivileges` (`listOfPrivileges`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `accounttype`:
--

--
-- Dumping data for table `accounttype`
--

INSERT INTO `accounttype` (`acTypeId`, `acTypeName`, `listOfPrivileges`) VALUES
(1, 'All privileges', 'GRANT ALL PRIVILEGES'),
(2, 'Insert and update', 'insert,update'),
(3, 'Read', 'select'),
(4, 'Read and delete', 'select,delete'),
(5, 'CRUD', 'select,insert,update,delete'),
(6, 'Update,delete', 'update,delete'),
(7, 'DEL', 'delete'),
(8, 'INS', 'insert'),
(9, 'UPD', 'update');
