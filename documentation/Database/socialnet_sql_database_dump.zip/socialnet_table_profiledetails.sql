
-- --------------------------------------------------------

--
-- Table structure for table `profiledetails`
--
-- Creation: Nov 29, 2025 at 07:54 PM
-- Last update: Nov 29, 2025 at 08:09 PM
--

DROP TABLE IF EXISTS `profiledetails`;
CREATE TABLE IF NOT EXISTS `profiledetails` (
  `proDetId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userId` int(10) UNSIGNED NOT NULL,
  `acTypeId` int(10) UNSIGNED DEFAULT NULL,
  `registrationDate` datetime NOT NULL,
  `pdUpdateDate` datetime NOT NULL,
  `accountStatus` enum('Active','Banned','Inactive') DEFAULT NULL,
  PRIMARY KEY (`proDetId`),
  KEY `userIdac_fk` (`userId`),
  KEY `acTypeId_fk` (`acTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `profiledetails`:
--   `acTypeId`
--       `accounttype` -> `acTypeId`
--   `userId`
--       `profile` -> `userId`
--

--
-- Dumping data for table `profiledetails`
--

INSERT INTO `profiledetails` (`proDetId`, `userId`, `acTypeId`, `registrationDate`, `pdUpdateDate`, `accountStatus`) VALUES
(1, 1, 3, '2025-11-29 21:09:54', '2025-11-30 00:00:00', 'Inactive');
