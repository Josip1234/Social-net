
-- --------------------------------------------------------

--
-- Table structure for table `subtopics`
--
-- Creation: Dec 14, 2025 at 07:39 PM
--

DROP TABLE IF EXISTS `subtopics`;
CREATE TABLE IF NOT EXISTS `subtopics` (
  `subTopicsId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `topicId` int(10) UNSIGNED NOT NULL,
  `subTopicContent` text NOT NULL,
  `subTopicDateAdded` datetime NOT NULL,
  `subTopicDateUpdated` datetime NOT NULL,
  `subtopicLike` int(10) UNSIGNED NOT NULL,
  `subtopicDislike` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`subTopicsId`),
  UNIQUE KEY `subTopicContent` (`subTopicContent`) USING HASH,
  KEY `topicId_fk` (`topicId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `subtopics`:
--   `topicId`
--       `topics` -> `topicId`
--
