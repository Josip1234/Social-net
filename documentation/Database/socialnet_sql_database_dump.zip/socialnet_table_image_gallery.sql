
-- --------------------------------------------------------

--
-- Table structure for table `image_gallery`
--
-- Creation: Dec 17, 2025 at 12:22 PM
--

DROP TABLE IF EXISTS `image_gallery`;
CREATE TABLE IF NOT EXISTS `image_gallery` (
  `galleryId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `galleryName` varchar(50) NOT NULL,
  `galleryDateAdded` datetime NOT NULL,
  `galleryDateUpdated` datetime DEFAULT NULL,
  PRIMARY KEY (`galleryId`),
  UNIQUE KEY `galleryName` (`galleryName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `image_gallery`:
--
