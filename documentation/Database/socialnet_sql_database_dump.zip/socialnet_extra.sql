
--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `postNumber_fk` FOREIGN KEY (`postNumber`) REFERENCES `city` (`postNumber`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `city`
--
ALTER TABLE `city`
  ADD CONSTRAINT `stateId_fk` FOREIGN KEY (`stateId`) REFERENCES `state` (`stateId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `addressId_fk` FOREIGN KEY (`addressId`) REFERENCES `address` (`addressId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profiledetails`
--
ALTER TABLE `profiledetails`
  ADD CONSTRAINT `acTypeId_fk` FOREIGN KEY (`acTypeId`) REFERENCES `accounttype` (`acTypeId`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `userIdac_fk` FOREIGN KEY (`userId`) REFERENCES `profile` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;
