
--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `postNumber_fk` FOREIGN KEY (`postNumber`) REFERENCES `city` (`postNumber`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `city`
--
ALTER TABLE `city`
  ADD CONSTRAINT `stateId_fk` FOREIGN KEY (`stateId`) REFERENCES `state` (`stateId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `database_logger`
--
ALTER TABLE `database_logger`
  ADD CONSTRAINT `user_id_fk` FOREIGN KEY (`userId`) REFERENCES `databaseuser` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `userid_imgid_fk` FOREIGN KEY (`userId`) REFERENCES `profile` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `imagedetails`
--
ALTER TABLE `imagedetails`
  ADD CONSTRAINT `imageId_fk` FOREIGN KEY (`imageId`) REFERENCES `image` (`imageId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `imagetype` (`typeId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `img_img_gal`
--
ALTER TABLE `img_img_gal`
  ADD CONSTRAINT `galleryId_fk` FOREIGN KEY (`galleryId`) REFERENCES `image_gallery` (`galleryId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `imageIdiig_fk` FOREIGN KEY (`imageId`) REFERENCES `image` (`imageId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `logger_content`
--
ALTER TABLE `logger_content`
  ADD CONSTRAINT `dbLogId_fk` FOREIGN KEY (`dbLogId`) REFERENCES `database_logger` (`dbLogId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `procomsub`
--
ALTER TABLE `procomsub`
  ADD CONSTRAINT `commentId_fk` FOREIGN KEY (`commentId`) REFERENCES `comments` (`commentId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `subtopicsid_pcs_fk` FOREIGN KEY (`subTopicsId`) REFERENCES `subtopics` (`subTopicsId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `userIdPcs_fk` FOREIGN KEY (`userId`) REFERENCES `profile` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `addressId_fk` FOREIGN KEY (`addressId`) REFERENCES `address` (`addressId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profiledetails`
--
ALTER TABLE `profiledetails`
  ADD CONSTRAINT `acTypeId_fk` FOREIGN KEY (`acTypeId`) REFERENCES `accounttype` (`acTypeId`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `userIdac_fk` FOREIGN KEY (`userId`) REFERENCES `profile` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile_logger`
--
ALTER TABLE `profile_logger`
  ADD CONSTRAINT `userIdpl_fk` FOREIGN KEY (`userId`) REFERENCES `profile` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subtopics`
--
ALTER TABLE `subtopics`
  ADD CONSTRAINT `topicId_fk` FOREIGN KEY (`topicId`) REFERENCES `topics` (`topicId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `topics`
--
ALTER TABLE `topics`
  ADD CONSTRAINT `user_id_topics_fk` FOREIGN KEY (`userId`) REFERENCES `profile` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;
