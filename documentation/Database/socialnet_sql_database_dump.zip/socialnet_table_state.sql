
-- --------------------------------------------------------

--
-- Table structure for table `state`
--
-- Creation: Nov 27, 2025 at 08:17 PM
-- Last update: Nov 27, 2025 at 08:17 PM
--

DROP TABLE IF EXISTS `state`;
CREATE TABLE IF NOT EXISTS `state` (
  `stateId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`stateId`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `state`:
--

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`stateId`, `name`) VALUES
(17, 'Australia'),
(16, 'Bangladesh'),
(12, 'Bosnia and Herzegovina'),
(7, 'Brazil'),
(14, 'China'),
(1, 'Croatia'),
(19, 'Denmark'),
(3, 'France'),
(22, 'Germany'),
(13, 'Hungary'),
(2, 'Italy'),
(5, 'Mexico'),
(11, 'Montenegro'),
(18, 'New Zeland'),
(9, 'Saudi Arabia'),
(10, 'Serbia'),
(23, 'Spain'),
(15, 'Taiwan'),
(8, 'Ukraine'),
(20, 'United Kingdom'),
(6, 'Uruguay'),
(4, 'USA'),
(21, 'Wales');
