
-- --------------------------------------------------------

--
-- Table structure for table `procomsub`
--
-- Creation: Dec 14, 2025 at 07:50 PM
--

DROP TABLE IF EXISTS `procomsub`;
CREATE TABLE IF NOT EXISTS `procomsub` (
  `proComSub` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userId` int(10) UNSIGNED NOT NULL,
  `commentId` int(10) UNSIGNED NOT NULL,
  `subTopicsId` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`proComSub`),
  KEY `userIdPcs_fk` (`userId`),
  KEY `commentId_fk` (`commentId`),
  KEY `subtopicsid_pcs_fk` (`subTopicsId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `procomsub`:
--   `commentId`
--       `comments` -> `commentId`
--   `subTopicsId`
--       `subtopics` -> `subTopicsId`
--   `userId`
--       `profile` -> `userId`
--
