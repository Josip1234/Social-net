
-- --------------------------------------------------------

--
-- Table structure for table `database_logger`
--
-- Creation: Dec 11, 2025 at 04:20 PM
--

DROP TABLE IF EXISTS `database_logger`;
CREATE TABLE IF NOT EXISTS `database_logger` (
  `dbLogId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userId` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`dbLogId`),
  KEY `user_id_fk` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `database_logger`:
--   `userId`
--       `databaseuser` -> `userId`
--
