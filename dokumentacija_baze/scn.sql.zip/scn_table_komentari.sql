
-- --------------------------------------------------------

--
-- Table structure for table `komentari`
--
-- Creation: Jun 06, 2017 at 12:25 PM
--

DROP TABLE IF EXISTS `komentari`;
CREATE TABLE IF NOT EXISTS `komentari` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `broj_teme` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  `datum_i_vrijeme_komentara` datetime NOT NULL,
  `komentar` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  KEY `broj_teme` (`broj_teme`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- RELATIONS FOR TABLE `komentari`:
--   `broj_teme`
--       `teme` -> `broj_teme`
--   `email`
--       `registration` -> `email`
--

--
-- Dumping data for table `komentari`
--

INSERT INTO `komentari` (`id`, `broj_teme`, `email`, `datum_i_vrijeme_komentara`, `komentar`) VALUES
(1, '1', 'jmale@gmail.com', '2017-06-14 00:00:00', 'nfnfnf');
