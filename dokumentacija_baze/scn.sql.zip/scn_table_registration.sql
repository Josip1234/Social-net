
-- --------------------------------------------------------

--
-- Table structure for table `registration`
--
-- Creation: Apr 17, 2017 at 07:47 AM
--

DROP TABLE IF EXISTS `registration`;
CREATE TABLE IF NOT EXISTS `registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) COLLATE utf8_croatian_ci NOT NULL,
  `lname` varchar(50) COLLATE utf8_croatian_ci NOT NULL,
  `sex` varchar(1) COLLATE utf8_croatian_ci NOT NULL,
  `dateofbirth` date NOT NULL,
  `cityofbirth` varchar(50) COLLATE utf8_croatian_ci NOT NULL,
  `countryofbirth` varchar(50) COLLATE utf8_croatian_ci NOT NULL,
  `pass` varchar(50) COLLATE utf8_croatian_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  `uloga` enum('Administrator','Korisnik','Banovani korisnik') COLLATE utf8_croatian_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- RELATIONS FOR TABLE `registration`:
--

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `fname`, `lname`, `sex`, `dateofbirth`, `cityofbirth`, `countryofbirth`, `pass`, `email`, `uloga`) VALUES
(10, 'Josip', 'Bošnjak', 'm', '1992-05-11', 'Wintherthur', 'Švicarska', 'm', 'jbosnjak3@gmail.com', 'Administrator'),
(11, 'Josipa', 'Malenica', 'z', '1988-05-12', 'Zagreb', 'Hrvatska', 'maz16', 'jmale@gmail.com', 'Administrator'),
(12, 'Marko', 'Marković', 'm', '1968-05-12', 'Fažana', 'Hrvatska', 'pass', 'mmarkovic@gmail.com', 'Korisnik');
