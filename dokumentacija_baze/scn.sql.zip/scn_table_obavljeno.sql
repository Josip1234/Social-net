
-- --------------------------------------------------------

--
-- Table structure for table `obavljeno`
--
-- Creation: Nov 02, 2017 at 10:53 AM
--

DROP TABLE IF EXISTS `obavljeno`;
CREATE TABLE IF NOT EXISTS `obavljeno` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_feedbacka` int(11) NOT NULL,
  `obavljeno` tinyint(1) NOT NULL,
  `email` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `user_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- RELATIONS FOR TABLE `obavljeno`:
--

--
-- Dumping data for table `obavljeno`
--

INSERT INTO `obavljeno` (`id`, `id_feedbacka`, `obavljeno`, `email`) VALUES
(3, 10, 1, 'jbosnjak3@gmail.com'),
(4, 12, 0, 'jbosnjak3@gmail.com'),
(7, 29, 1, 'jbosnjak3@gmail.com'),
(8, 9, 1, 'jbosnjak3@gmail.com'),
(9, 25, 1, 'jbosnjak3@gmail.com'),
(10, 23, 1, 'jbosnjak3@gmail.com'),
(11, 17, 1, 'jbosnjak3@gmail.com'),
(12, 21, 1, 'jbosnjak3@gmail.com'),
(13, 30, 1, 'jbosnjak3@gmail.com'),
(14, 18, 0, 'jbosnjak3@gmail.com'),
(15, 28, 1, 'jbosnjak3@gmail.com'),
(16, 20, 0, 'jbosnjak3@gmail.com'),
(17, 22, 1, 'jbosnjak3@gmail.com'),
(18, 15, 0, 'jbosnjak3@gmail.com'),
(19, 33, 1, 'jbosnjak3@gmail.com'),
(20, 27, 1, 'jbosnjak3@gmail.com');
