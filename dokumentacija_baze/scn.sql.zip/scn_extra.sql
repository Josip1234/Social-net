
--
-- Constraints for dumped tables
--

--
-- Constraints for table `galerija`
--
ALTER TABLE `galerija`
  ADD CONSTRAINT `typeofgal` FOREIGN KEY (`type_of_gallery`) REFERENCES `kategorije` (`type_of_gallery`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `komentari`
--
ALTER TABLE `komentari`
  ADD CONSTRAINT `brojteme` FOREIGN KEY (`broj_teme`) REFERENCES `teme` (`broj_teme`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `email` FOREIGN KEY (`email`) REFERENCES `registration` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profilna`
--
ALTER TABLE `profilna`
  ADD CONSTRAINT `em` FOREIGN KEY (`email`) REFERENCES `registration` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teme`
--
ALTER TABLE `teme`
  ADD CONSTRAINT `teme_ibfk_1` FOREIGN KEY (`email`) REFERENCES `registration` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;
