
-- --------------------------------------------------------

--
-- Table structure for table `kategorije`
--
-- Creation: Nov 05, 2017 at 09:01 AM
--

DROP TABLE IF EXISTS `kategorije`;
CREATE TABLE IF NOT EXISTS `kategorije` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_of_gallery` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type_of_gallery_2` (`type_of_gallery`),
  KEY `type_of_gallery` (`type_of_gallery`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- RELATIONS FOR TABLE `kategorije`:
--

--
-- Dumping data for table `kategorije`
--

INSERT INTO `kategorije` (`id`, `type_of_gallery`) VALUES
(4, 'animal'),
(7, 'animatedpeople'),
(14, 'boots'),
(3, 'femaleactress'),
(1, 'femaledancers'),
(5, 'femalemodels'),
(6, 'femalesingers'),
(8, 'photoshopped'),
(17, 'porn'),
(2, 'rest'),
(18, 'san andreas'),
(10, 'sportcars'),
(9, 'supercars'),
(19, 'test');
