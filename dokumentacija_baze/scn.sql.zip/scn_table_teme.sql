
-- --------------------------------------------------------

--
-- Table structure for table `teme`
--
-- Creation: Apr 17, 2017 at 07:47 AM
--

DROP TABLE IF EXISTS `teme`;
CREATE TABLE IF NOT EXISTS `teme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  `broj_teme` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  `naziv_teme` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `broj_teme` (`broj_teme`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- RELATIONS FOR TABLE `teme`:
--   `email`
--       `registration` -> `email`
--

--
-- Dumping data for table `teme`
--

INSERT INTO `teme` (`id`, `email`, `broj_teme`, `naziv_teme`) VALUES
(1, 'jbosnjak3@gmail.com', '1', 'Sport');
